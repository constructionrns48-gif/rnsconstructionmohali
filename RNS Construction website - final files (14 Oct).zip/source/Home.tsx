import React, { useEffect, useRef } from 'react';
import { Link } from '@instinct/files';
import { IMG } from './data';

function StatN({ value }: { value: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const finalTxt = el.textContent || '';
    const m = finalTxt.match(/^([\d,]+)(.*)$/);
    if (!m) return;
    const target = parseInt(m[1].replace(/,/g, ''), 10);
    const suffix = m[2];
    let done = false;
    const io = new IntersectionObserver((es) => {
      for (const e of es) {
        if (e.isIntersecting && !done) {
          done = true;
          const t0 = performance.now();
          const dur = 1300;
          const tick = (t: number) => {
            const p = Math.min(1, (t - t0) / dur);
            const eased = 1 - Math.pow(1 - p, 3);
            el.textContent = Math.round(target * eased).toLocaleString('en-US') + suffix;
            if (p < 1) requestAnimationFrame(tick); else el.textContent = finalTxt;
          };
          requestAnimationFrame(tick);
          io.disconnect();
        }
      }
    }, { threshold: 0.4 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return <div className="n" ref={ref}>{value}</div>;
}
import { EnquirySection, ContactSection } from './components';

export function Home() {
  return <main>
<section className="hero" id="home">
<div className="bg" role="img" aria-label="Modern luxury house constructed in Punjab"></div><div className="ov"></div>
<div className="wrap"><div className="hero-in">
<span className="hero-eyebrow">RNS Construction Mohali</span>
<h1>Building Your Dream, <span className="g">Building Your Future.</span></h1>
<p className="sub">Expert House Construction, Turnkey Projects &amp; Architectural Solutions in Mohali, Chandigarh and Nearby Areas.</p>
<p className="desc">From architectural planning and structural construction to turnkey execution and interior finishing, RNS Construction Mohali helps bring your residential and commercial construction vision to life.</p>
<div className="hero-cta">
<a className="btn btn-gold" href="#enquiry">Get Free Quote</a>
<a className="btn btn-wa" href="https://wa.me/918750510489?text=Hi%2C%20I%20want%20free%20site%20visit" target="_blank" rel="noopener"><svg className="wa-ic" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413"/></svg>WhatsApp Us</a>
</div>
<div className="hero-trust">
<span className="t"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l2.9 6.3 6.9.8-5.1 4.7 1.4 6.8L12 17.2 5.9 20.6l1.4-6.8L2.2 9.1l6.9-.8z"/></svg>5.0 on Google</span>
<span className="t"><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>Free Site Visit</span>
<span className="t"><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg>Quality-Focused Work</span>
</div>
</div></div>
</section>
<section className="sec" id="about"><div className="wrap"><div className="about-grid">
<div>
<span className="kicker">About RNS Construction Mohali</span>
<h2>Building Your Dreams into Reality</h2>
<p>RNS Construction Mohali is a growing construction and real estate development company serving Mohali, Chandigarh and the wider Punjab region. We focus on quality construction, transparent communication and architectural excellence.</p>
<p>Whether you are planning a modern independent house, luxury villa, commercial complex or complete turnkey construction project, our aim is to deliver thoughtful design, dependable execution and lasting value.</p>
<Link className="link-more" to="/about">Read More About Us<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></Link>
</div>
<div className="about-imgs">
<img src={IMG.img4} alt="Modern independent house design" loading="lazy"/>
<img src={IMG.img7} alt="Premium home interior design" loading="lazy"/>
<img src={IMG.img3} alt="Contemporary building elevation" loading="lazy"/>
</div>
</div></div></section>
<section className="sec founder" id="founder"><div className="wrap"><div className="founder-grid">
<div className="founder-card">
<div className="monogram" aria-hidden="true">NK</div>
<div className="fc-name">Ar. Naveen Kumar</div>
<div className="fc-role">Founder &amp; Senior Architect</div>
</div>
<div className="founder-txt">
<span className="kicker">Meet Our Founder &amp; Managing Director</span>
<h2>Ar. Naveen Kumar</h2>
<p>Ar. Naveen Kumar brings 15+ years of industry experience, according to the company's professional profile. His professional background includes four years with a corporate construction company, with experience in project execution, structural engineering standards and quality management.</p>
<p>With a vision for reliable construction and thoughtful architectural design, he established RNS Construction Mohali. His leadership focuses on quality workmanship, transparent communication, project coordination and customer satisfaction.</p>
</div>
</div></div></section>
<section className="stats" aria-label="Company statistics"><div className="wrap"><div className="stats-grid">
<div className="stat"><StatN value="10+" /><div className="l">Years of Experience</div></div>
<div className="stat"><StatN value="25,000+" /><div className="l">Sq Ft Construction</div></div>
<div className="stat"><StatN value="30+" /><div className="l">Residential &amp; Commercial Projects</div></div>
</div></div></section>
<section className="sec alt" id="why"><div className="wrap">
<div className="sec-head"><span className="kicker">Why Choose Us</span><h2>Why Choose RNS Construction?</h2><p>Dependable construction led by experience, transparency and careful coordination.</p></div>
<div className="why-grid">
<div className="why-card"><div className="why-ic"><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="6"/><path d="M15.5 12.9 17 22l-5-3-5 3 1.5-9.1"/></svg></div><h3>Experienced Leadership</h3><p>Construction expertise guided by Ar. Naveen Kumar.</p></div>
<div className="why-card"><div className="why-ic"><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01M16 6h.01M12 6h.01M12 10h.01M12 14h.01M16 10h.01M16 14h.01M8 10h.01M8 14h.01"/></svg></div><h3>Turnkey Solutions</h3><p>Architectural planning, structural work, construction and finishing.</p></div>
<div className="why-card"><div className="why-ic"><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M6 3h12M6 8h12M6 13l8.5 8M6 13h3M9 13c6.667 0 6.667-10 0-10"/></svg></div><h3>Transparent Pricing</h3><p>Detailed estimates and clear communication about costs.</p></div>
<div className="why-card"><div className="why-ic"><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg></div><h3>Quality-Focused Construction</h3><p>Appropriate materials, engineering practices and workmanship.</p></div>
<div className="why-card"><div className="why-ic"><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/></svg></div><h3>Project Coordination</h3><p>Careful planning, progress updates and attention to agreed timelines.</p></div>
</div></div></section>
<section className="sec" id="services"><div className="wrap">
<div className="sec-head"><span className="kicker">Our Services</span><h2>Complete Construction Services</h2><p>From planning to finishing, one team for your entire project.</p></div>
<div className="svc-grid">
<div className="svc-card"><img src={IMG.img4} alt="Modern independent house design" loading="lazy"/><div className="svc-body"><h3>Residential House Construction</h3><p>Modern independent houses, kothis and villas built with quality materials and careful planning.</p><Link className="enq" to="/services/house-construction">Enquire Now<svg viewBox="0 0 24 24" fill="none" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></Link></div></div>
<div className="svc-card"><img src={IMG.img3} alt="Contemporary building elevation" loading="lazy"/><div className="svc-body"><h3>Commercial Building Construction</h3><p>Showrooms, shops, offices and commercial buildings executed to engineering standards.</p><Link className="enq" to="/services/commercial-building">Enquire Now<svg viewBox="0 0 24 24" fill="none" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></Link></div></div>
<div className="svc-card"><img src={IMG.img8} alt="Luxury villa design" loading="lazy"/><div className="svc-body"><h3>Turnkey Construction Projects</h3><p>Design to key handover: planning, construction, interiors and finishing by one team.</p><Link className="enq" to="/services/turnkey-projects">Enquire Now<svg viewBox="0 0 24 24" fill="none" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></Link></div></div>
<div className="svc-card"><img src={IMG.img5} alt="Architectural and structural design services" loading="lazy"/><div className="svc-body"><h3>Architectural &amp; Structural Design</h3><p>Thoughtful architectural drawings and structural engineering for safe, practical buildings.</p><Link className="enq" to="/services/architectural-design">Enquire Now<svg viewBox="0 0 24 24" fill="none" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></Link></div></div>
<div className="svc-card"><img src={IMG.img2} alt="Elegant living room interior design" loading="lazy"/><div className="svc-body"><h3>Interior Design</h3><p>Functional, premium interiors for homes and commercial spaces, matched to your taste.</p><Link className="enq" to="/services/interior-design">Enquire Now<svg viewBox="0 0 24 24" fill="none" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></Link></div></div>
<div className="svc-card"><img src={IMG.img7} alt="Premium home interior design" loading="lazy"/><div className="svc-body"><h3>Home Renovation &amp; Remodelling</h3><p>Renovation, remodelling, repair and extension work that upgrades your existing space.</p><Link className="enq" to="/services/renovation">Enquire Now<svg viewBox="0 0 24 24" fill="none" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></Link></div></div>
</div>
<p style={{textAlign: 'center', marginTop: '30px'}}><Link className="link-more" to="/services">View All Services<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></Link></p>
</div></section>
<section className="sec alt" id="projects"><div className="wrap">
<div className="sec-head"><span className="kicker">Design Inspiration</span><h2>Architecture &amp; Design Inspiration</h2><p>Architectural styles, elevations and finishes our team can design and build for your project.</p></div>
<div className="proj-grid">
<div className="proj"><img src={IMG.img4} alt="Modern house construction design" loading="lazy"/><div className="pl">Modern House Design</div></div>
<div className="proj"><img src={IMG.img8} alt="Luxury villa design" loading="lazy"/><div className="pl">Luxury Villa Design</div></div>
<div className="proj"><img src={IMG.img6} alt="Residential building design" loading="lazy"/><div className="pl">Residential Building Design</div></div>
<div className="proj"><img src={IMG.img3} alt="Commercial construction design" loading="lazy"/><div className="pl">Commercial Architecture</div></div>
<div className="proj"><img src={IMG.img1} alt="Exterior elevation design" loading="lazy"/><div className="pl">Exterior Elevation Design</div></div>
<div className="proj"><img src={IMG.img7} alt="Home interior design" loading="lazy"/><div className="pl">Interior Design</div></div>
</div>

</div></section>
<section className="sec" id="pricing"><div className="wrap">
<div className="sec-head"><span className="kicker">Construction Packages</span><h2>Construction Options for Every Budget</h2><p>Overall turnkey construction cost (material + labour). Clear packages and detailed estimates.</p></div>
<div className="price-grid">
<div className="price-card"><h3>Civil Construction</h3><p className="pd">Brick work and plaster, material + labour.</p><p className="pr">&#8377;1,100 <span>per sq. ft.</span></p><ul><li>Brick work and plaster</li><li>Material and labour included</li></ul><a className="btn btn-ghost" style={{color: 'var(--navy)', borderColor: 'var(--navy)'}} href="#enquiry">Get Free Estimate</a></div>
<div className="price-card hot"><h3>Standard Finishing</h3><p className="pd">Good-quality standard finishing, material + labour.</p><p className="pr">&#8377;2,600 &ndash; &#8377;2,800 <span>per sq. ft.</span></p><ul><li>Good-quality tiles and flooring</li><li>Semi modular kitchen</li><li>Branded sanitary &amp; electrical fittings</li></ul><a className="btn btn-gold" href="#enquiry">Get Free Estimate</a></div>
<div className="price-card"><h3>Premium / Luxury Finishing</h3><p className="pd">High-end luxury construction, material + labour.</p><p className="pr">&#8377;3,000 &ndash; &#8377;4,500+ <span>per sq. ft.</span></p><ul><li>Imported / high-end materials</li><li>Custom design</li><li>Luxury finishes</li></ul><a className="btn btn-ghost" style={{color: 'var(--navy)', borderColor: 'var(--navy)'}} href="#enquiry">Get Free Estimate</a></div>
</div>
<p className="price-note">Final estimates depend on location, built-up area, drawings, materials, specifications and site conditions. Share your requirements for a detailed free quotation.</p>
</div></section>
<section className="sec areas" id="areas"><div className="wrap">
<div className="sec-head"><span className="kicker">Service Areas</span><h2>Serving Mohali, Chandigarh &amp; Nearby Areas</h2><p>Free site visit available across our service locations.</p></div>
<div className="area-chips">
<span className="chip"><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>Mohali</span>
<span className="chip"><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>Chandigarh</span>
<span className="chip"><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>Zirakpur</span>
<span className="chip"><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>Panchkula</span>
<span className="chip"><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>Kharar</span>
<span className="chip"><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>New Chandigarh</span>
</div></div></section>
<section className="sec" id="reviews"><div className="wrap">
<div className="sec-head"><span className="kicker">Testimonials</span><h2>What Our Customers Say</h2><p>Genuine reviews from our Google Business Profile.</p></div>
<div className="rev-card">
<div className="rev-score"><div className="rs">5.0</div><div className="rev-stars" aria-label="5 out of 5 stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><div className="rc">Google Rating</div></div>
<div className="rev-txt">
<h3>Rated by our customers on Google</h3>
<p>RNS Construction Mohali is rated 5.0 out of 5 by customers on its verified Google Business Profile. Read genuine customer reviews and see what people say about our work.</p>
<a className="btn btn-gold" href="https://share.google/OkGZxYW0gj5gXvu1u" target="_blank" rel="noopener">View Google Reviews</a>
</div>
</div></div></section>
    <EnquirySection />
    <ContactSection />
  </main>;
}
