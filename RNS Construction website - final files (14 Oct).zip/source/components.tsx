import React, { useEffect, useRef, useState } from 'react';
import { Link, NavLink } from '@instinct/files';
import { MAPS_DIR, ADDRESS, AREAS, EMAIL, FACEBOOK, IMG, INSTAGRAM, PHONE, PHONE_DISPLAY, REVIEWS_URL, SERVICES, WA_MSG, YOUTUBE } from './data';

const WA_ICON = <svg className="wa-ic" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413"/></svg>;

export function waSvg() { return WA_ICON; }

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return <header className="header"><div className="wrap">
    <Link to="/" className="brand" aria-label="RNS Construction Mohali home" onClick={close}>
      <img src={IMG.logo} alt="RNS Construction Mohali logo" width={46} height={46} />
      <div><div className="bn">RNS <span>Construction</span></div><div className="bs">Mohali &middot; Building Your Dream</div></div>
    </Link>
    <nav className="nav" aria-label="Main navigation">
      <NavLink to="/" end>Home</NavLink>
      <NavLink to="/about">About Us</NavLink>
      <span className="has-dd">
        <NavLink to="/services">Services</NavLink>
        <span className="dd">
          {SERVICES.map(s => <Link key={s.slug} to={`/services/${s.slug}`}>{s.name}</Link>)}
        </span>
      </span>
      <NavLink to="/projects">Projects</NavLink>
      <span className="has-dd">
        <NavLink to="/areas/mohali">Areas</NavLink>
        <span className="dd">
          {AREAS.map(a => <Link key={a.slug} to={`/areas/${a.slug}`}>{a.name}</Link>)}
        </span>
      </span>
      <NavLink to="/faq">FAQ</NavLink>
    </nav>
    <div className="h-cta">
      <a className="btn btn-wa" href={WA_MSG('Hello RNS Construction Mohali, I would like to enquire about your construction services. Please contact me regarding my project.')} target="_blank" rel="noopener">{WA_ICON}WhatsApp</a>
      <a className="btn btn-gold" href="#enquiry">Get Free Quote</a>
    </div>
    <button className="burger" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} onClick={() => setOpen(!open)}>
      <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
    </button>
  </div>
  {open && <div className="m-menu open">
    <Link to="/" onClick={close}>Home</Link>
    <Link to="/about" onClick={close}>About Us</Link>
    <Link to="/services" onClick={close}>Services</Link>
    <div className="m-grp">Services</div>
    {SERVICES.map(s => <Link key={s.slug} to={`/services/${s.slug}`} onClick={close}>{s.name}</Link>)}
    <Link to="/projects" onClick={close}>Projects</Link>
    <div className="m-grp">Areas We Serve</div>
    {AREAS.map(a => <Link key={a.slug} to={`/areas/${a.slug}`} onClick={close}>{a.name}</Link>)}
    <Link to="/faq" onClick={close}>FAQ</Link>
    <a className="btn btn-gold" href="#enquiry" onClick={close}>Get Free Quote</a>
    <a className="btn btn-wa" href={WA_MSG('Hello RNS Construction Mohali, I would like to enquire about your construction services. Please contact me regarding my project.')} target="_blank" rel="noopener">WhatsApp Enquiry</a>
  </div>}
  </header>;
}

export function PageHero({ kicker, h1, intro }: { kicker: string; h1: string; intro: string }) {
  return <section className="page-hero"><div className="wrap">
    <span className="kicker">{kicker}</span>
    <h1>{h1}</h1>
    <p>{intro}</p>
  </div></section>;
}

export function Steps() {
  return <section className="sec alt"><div className="wrap">
    <div className="sec-head"><span className="kicker">How We Work</span><h2>Simple, Transparent 4-Step Process</h2><p>From first call to key handover.</p></div>
    <div className="step-grid">
      <div className="step"><b>1. Consultation</b><span>Call or WhatsApp us. Share your plot details, budget and requirements.</span></div>
      <div className="step"><b>2. Design & Quotation</b><span>We prepare design options and a clear item-wise quotation.</span></div>
      <div className="step"><b>3. Construction</b><span>Work starts with regular photo and video updates. You can visit the site anytime.</span></div>
      <div className="step"><b>4. Key Handover</b><span>Quality check, final finishing and the keys of your dream home handed over.</span></div>
    </div>
  </div></section>;
}

export function EnquirySection() {
  const [label, setLabel] = useState('Submit Enquiry on WhatsApp');
  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = e.currentTarget;
    const get = (n: string) => (f.elements.namedItem(n) as HTMLInputElement)?.value?.trim() || '';
    const name = get('name'), phone = get('phone');
    if (!name) { (f.elements.namedItem('name') as HTMLInputElement).focus(); return; }
    if (!/^[0-9+()\-\s]{10,15}$/.test(phone)) { (f.elements.namedItem('phone') as HTMLInputElement).focus(); return; }
    setLabel('Opening WhatsApp...');
    const lines = ['Hello RNS Construction Mohali, I would like to enquire about your construction services.', '', `Name: ${name}`, `Mobile: ${phone}`];
    if (get('location')) lines.push(`Location: ${get('location')}`);
    if (get('property-type')) lines.push(`Property Type: ${get('property-type')}`);
    if (get('service')) lines.push(`Service: ${get('service')}`);
    if (get('area')) lines.push(`Plot / Area: ${get('area')}`);
    if (get('message')) lines.push(`Message: ${get('message')}`);
    window.open(WA_MSG(lines.join('\n')), '_blank');
    setLabel('Enquiry opened in WhatsApp');
    setTimeout(() => setLabel('Submit Enquiry on WhatsApp'), 4000);
  }
  return <section className="sec enquiry" id="enquiry"><div className="wrap"><div className="enq-grid">
    <div className="enq-info">
      <span className="kicker">Send Enquiry</span>
      <h2>Tell Us About Your Project</h2>
      <p>Share your plot, budget and requirements. The form opens WhatsApp with your details filled in - review and send it yourself. You can also call us directly at <a href={`tel:${PHONE}`}>{PHONE_DISPLAY}</a>.</p>
      <ul className="check-list">
        <li>Free site visit across Mohali, Chandigarh, Zirakpur, Panchkula and Kharar</li>
        <li>Clear, item-wise quotation</li>
        <li>Design, materials and scope discussed before work starts</li>
      </ul>
    </div>
    <form className="enq-form" onSubmit={onSubmit} noValidate>
      <div className="fg"><label htmlFor="name">Full Name *</label><input type="text" id="name" name="name" required autoComplete="name" placeholder="Your full name" /></div>
      <div className="fg"><label htmlFor="phone">Mobile Number *</label><input type="tel" id="phone" name="phone" required autoComplete="tel" inputMode="numeric" pattern="[0-9+ -]{10,15}" placeholder="10 digit mobile" /></div>
      <div className="fg"><label htmlFor="location">Project Location</label><input type="text" id="location" name="location" placeholder="Mohali / Zirakpur / Chandigarh..." /></div>
      <div className="fg"><label htmlFor="property-type">Property Type</label><select id="property-type" name="property-type"><option value="">Select property type</option><option>House / Kothi / Villa / Bungalow</option><option>Commercial Building</option><option>Plot / Grey Structure</option><option>Other</option></select></div>
      <div className="fg"><label htmlFor="service">Required Service</label><select id="service" name="service"><option>House Construction</option><option>Commercial Construction</option><option>Turnkey Project</option><option>Architectural / Structural Design</option><option>Interior Design</option><option>Renovation / Remodelling</option><option>Other</option></select></div>
      <div className="fg"><label htmlFor="area">Plot / Built-up Area (if known)</label><input type="text" id="area" name="area" placeholder="e.g. 250 sq yd plot, 2000 sq ft built-up" /></div>
      <div className="fg"><label htmlFor="message">Message / Project Requirements</label><textarea id="message" name="message" rows={3} placeholder="Plot size, budget or any detail..."></textarea></div>
      <button type="submit" className="btn btn-wa form-go"><span>{label}</span></button>
    </form>
  </div></div></section>;
}

export function ContactSection() {
  return <section className="sec alt" id="contact"><div className="wrap">
    <div className="sec-head"><span className="kicker">Contact</span><h2>Contact RNS Construction Mohali</h2><p>Visit our office in Phase 11, Mohali or call / WhatsApp for a free site visit.</p></div>
    <div className="ct-grid">
      <div className="ct-card"><h3>Call Us</h3><p><a href={`tel:${PHONE}`}>{PHONE_DISPLAY}</a><br />Mon-Sat, 9 AM - 7 PM</p></div>
      <div className="ct-card"><h3>WhatsApp</h3><p><a href={WA_MSG('Hi, I want free site visit')} target="_blank" rel="noopener">{PHONE_DISPLAY}</a><br />Fastest response</p></div>
      <div className="ct-card"><h3>Email</h3><p><a href={`mailto:${EMAIL}`}>{EMAIL}</a></p></div>
      <div className="ct-card"><h3>Office</h3><p>{ADDRESS}</p></div>
    </div>
    <p style={{ textAlign: 'center', marginTop: 26, fontSize: '.95rem', color: 'var(--muted)' }}>Follow us: <a className="soc" style={{ color: 'var(--navy)', fontWeight: 700 }} href={INSTAGRAM} target="_blank" rel="noopener">Instagram @rnsconstruction99</a> &nbsp;&middot;&nbsp; <a className="soc" style={{ color: 'var(--navy)', fontWeight: 700 }} href={YOUTUBE} target="_blank" rel="noopener">YouTube: RNS Construction Mohali</a></p>
  </div></section>;
}

export function SiteFooter() {
  const [subStatus, setSubStatus] = useState('');
  function onSubscribe(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = e.currentTarget;
    const email = (f.elements.namedItem('email') as HTMLInputElement).value;
    setSubStatus('Subscribing...');
    fetch('https://formsubmit.co/ajax/constructionrns48@gmail.com', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ email }),
    }).then(r => { if (!r.ok) throw 0; setSubStatus('Thank you! Please check your inbox.'); f.reset(); })
      .catch(() => setSubStatus('Could not subscribe right now. Please try again.'));
  }
  return <footer className="footer"><div className="wrap">
    <div className="f-grid">
      <div className="f-brand">
        <img src={IMG.logo} alt="RNS Construction Mohali logo" width={50} height={50} loading="lazy" />
        <div className="fbn">RNS Construction Mohali</div>
        <div className="fbt">Building Your Dream, Building Your Future.</div>
        <p>Premium house construction, turnkey projects, architectural design, interiors and renovation across Mohali, Chandigarh and Punjab.</p>
        <div className="f-soc">
          <a href={INSTAGRAM} target="_blank" rel="noopener noreferrer" aria-label="RNS Construction on Instagram"><svg viewBox="0 0 24 24" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".7" fill="currentColor"/></svg></a>
          <a href={FACEBOOK} target="_blank" rel="noopener noreferrer" aria-label="RNS Construction on Facebook"><svg viewBox="0 0 24 24" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
          <a href={YOUTUBE} target="_blank" rel="noopener noreferrer" aria-label="RNS Construction on YouTube"><svg viewBox="0 0 24 24" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-1.92 29 29 0 0 0 .46-5.33 29 29 0 0 0-.46-5.33z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48" fill="currentColor" stroke="none"/></svg></a>
        </div>
      </div>
      <div><h4>Quick Links</h4><nav aria-label="Footer quick links"><Link to="/">Home</Link><Link to="/about">About Us</Link><Link to="/services">Services</Link><Link to="/projects">Projects</Link><Link to="/faq">FAQ</Link><Link to="/blog">Blog</Link><Link to="/terms">Terms</Link></nav></div>
      <div><h4>Our Services</h4><nav aria-label="Footer services">{SERVICES.map(s => <Link key={s.slug} to={`/services/${s.slug}`}>{s.name}</Link>)}</nav></div>
      <div><h4>Contact Us</h4><div className="f-ct">
        SCF 103, 1st Floor, Phase 11,<br />Above Gadget World, Mohali, Punjab 160062<br />
        <a href={`tel:${PHONE}`}>{PHONE_DISPLAY}</a><br />
        <a href={`mailto:${EMAIL}`}>{EMAIL}</a><br />
        <a className="f-dir" href={MAPS_DIR} target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width={14} height={14} aria-hidden="true" style={{verticalAlign:'-2px',marginRight:5}}><path d="M12 21s-7-5.1-7-11a7 7 0 1 1 14 0c0 5.9-7 11-7 11z"/><circle cx="12" cy="10" r="2.6"/></svg>Get Directions - distance from your location</a>
      </div></div>
    </div>
    <div className="f-sub"><div><h4>Subscribe</h4><p>Get construction tips, price updates and new project photos by email.</p></div>
      <form onSubmit={onSubscribe}>
        <label htmlFor="subscriber-email" style={{ position: 'absolute', width: 1, height: 1, overflow: 'hidden', clip: 'rect(0,0,0,0)' }}>Email address</label>
        <input id="subscriber-email" type="email" autoComplete="email" placeholder="you@example.com" required name="email" />
        <button type="submit">Subscribe</button>
        {subStatus && <p className="sub-status" role="status">{subStatus}</p>}
      </form></div>
    <p className="f-areas">Serving Mohali, Chandigarh, Zirakpur, Panchkula, Kharar and New Chandigarh</p>
    <div className="f-bottom"><span>&copy; 2026 RNS Construction Mohali. All rights reserved.</span><span className="f-powered">Powered by <a href="https://vaynaify.buzz" target="_blank" rel="noopener noreferrer">vaynaify.buzz</a></span><span><Link to="/terms">Terms</Link></span></div>
  </div></footer>;
}

const CHAT_ANSWERS: Record<string, string> = {
  'Our services': 'We provide house construction, commercial building construction, turnkey projects, architectural and structural design, interior design, and home renovation across Mohali, Chandigarh and nearby areas.',
  'Areas we serve': 'We serve Mohali, Chandigarh, Zirakpur, Panchkula, Kharar and New Chandigarh. Free site visit is available across these areas.',
  'Get a quotation': 'Share your plot size, location and requirements and we will give you a detailed free estimate. Final cost depends on plot size, design, materials and site conditions.',
  'Contact & office': 'Office: SCF 103, 1st Floor, Phase 11, Above Gadget World, Mohali, Punjab 160062. Call or WhatsApp: +91 87505 10489.',
};

export function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [sel, setSel] = useState<string | null>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const ansRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const b = bodyRef.current, a = ansRef.current;
    if (b && a) b.scrollTop += a.getBoundingClientRect().top - b.getBoundingClientRect().top - 6;
  }, [sel]);
  return <div className="rns-chat-widget">
    <button className="rns-chat-launch" type="button" aria-label="Ask RNS - quick answers" aria-expanded={open} onClick={() => setOpen(!open)}>
      <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>Ask RNS
    </button>
    {open && <div className="rns-chat-panel open" role="dialog" aria-label="Ask RNS quick help">
      <div className="rns-chat-head"><div><div className="t">Ask RNS</div><div className="s">Quick answers about our construction services</div></div><button className="rns-chat-close" aria-label="Close chat" onClick={() => setOpen(false)}>&times;</button></div>
      <div className="rns-chat-body" ref={bodyRef}>
        {Object.keys(CHAT_ANSWERS).map(k => <button key={k} className={"rns-chat-q" + (sel === k ? " sel" : "")} onClick={() => setSel(k)}>{k}</button>)}
        {sel && <div className="rns-chat-a" ref={ansRef}>{CHAT_ANSWERS[sel]}
          {sel === 'Contact & office' && <a className="rns-chat-map" target="_blank" rel="noopener" href={MAPS_DIR}>Open in Google Maps</a>}
          <a className="rns-chat-wa" target="_blank" rel="noopener" href={WA_MSG(`Hi, I want a site visit for RNS Construction. Topic: ${sel}`)}>Chat on WhatsApp</a>
        </div>}
      </div>
      <div className="rns-chat-foot"><small>Free site visit &middot; Mohali, Chandigarh &amp; nearby areas</small></div>
    </div>}
  </div>;
}

export function WaFloat() {
  return <>
    <a className="float-quote" href="#enquiry" aria-label="Get a free quotation from RNS Construction">
      <svg viewBox="0 0 24 24" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 13h6"/><path d="M9 17h6"/></svg>
    </a>
    <a className="float-call" href={`tel:${PHONE}`} aria-label="Call RNS Construction Mohali">
      <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
    </a>
    <a className="float-wa" href={WA_MSG('Hi, I want free site visit')} target="_blank" rel="noopener" aria-label="Chat with RNS Construction on WhatsApp">
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413"/></svg>
  </a>
  </>;
}

export function ReviewsStrip() {
  return <section className="sec" id="reviews"><div className="wrap">
    <div className="sec-head"><span className="kicker">Google Reviews</span><h2>Rated 5.0 on Google</h2><p>Real reviews from real customers on our Google Business Profile.</p></div>
    <div style={{ textAlign: 'center' }}>
      <a className="btn btn-gold" href={REVIEWS_URL} target="_blank" rel="noopener">View Google Reviews</a>
    </div>
  </div></section>;
}
