import React from 'react';
import { Link } from '@instinct/files';
import { AREAS, IMG, PACKAGES, REVIEWS_URL, SERVICES, STATS, WA_MSG, Area, Service } from './data';
import { ContactSection, EnquirySection, PageHero, Steps } from './components';

export function AboutPage() {
  return <main>
    <PageHero kicker="About Us" h1="RNS Construction Mohali - We Build Your Dream" intro="A construction company, builder and contractor based in Mohali, Punjab - serving homeowners and businesses across Tricity." />
    <section className="sec"><div className="wrap"><div className="two-col">
      <div>
        <p>RNS Construction Mohali is a construction company, builder and contractor based in Mohali, Punjab. We help homeowners and businesses with house construction, renovation and interior work across Mohali, Chandigarh, Zirakpur, Kharar, Panchkula, New Chandigarh, Sunny Enclave, Landran, Banur and nearby areas.</p>
        <p>From houses, kothis, villas and independent floors to commercial buildings, showrooms, shops and offices, we handle construction and finishing under one roof. Our services also include home renovation, repairs, extensions and interior design, with false ceilings, flooring and painting.</p>
        <p>For turnkey projects, we bring design, construction and interiors together through to key handover. We also carry out civil work, including foundations, RCC columns, boundary walls, and AAC block and brick walls.</p>
        <p>Tell us about your plot and the space you want to build. Our team can discuss your design, materials and scope of work, arrange a free site visit and prepare a project-specific quotation.</p>
      </div>
      <div>
        <img src={IMG.img4} alt="Modern independent house design" style={{ borderRadius: 16, width: '100%' }} />
        <div className="stats" style={{ marginTop: 18 }}><div className="stats-grid">
          {STATS.map(s => <div key={s.l} className="stat"><b>{s.n}</b><span>{s.l}</span></div>)}
        </div></div>
      </div>
    </div></div></section>
    <Steps />
    <EnquirySection />
    <ContactSection />
  </main>;
}

export function ServicesPage() {
  return <main>
    <PageHero kicker="Our Services" h1="Complete Construction Solutions Under One Roof" intro="From foundation to interiors - house construction, commercial buildings, turnkey projects, design and renovation across Mohali, Chandigarh and nearby areas." />
    <section className="sec"><div className="wrap">
      <div className="link-cards">
        {SERVICES.map(s => <Link key={s.slug} className="link-card" to={`/services/${s.slug}`}>
          <b>{s.name}</b><span>{s.intro}</span><span className="go">View details &rarr;</span>
        </Link>)}
      </div>
    </div></section>
    <section className="sec alt" id="pricing"><div className="wrap">
      <div className="sec-head"><span className="kicker">Construction Packages</span><h2>Construction Options for Every Budget</h2><p>Overall turnkey construction cost (material + labour). Clear packages and detailed estimates.</p></div>
      <div className="price-grid">
        {PACKAGES.map(p => <div key={p.name} className={p.hot ? 'price-card hot' : 'price-card'}><h3>{p.name}</h3><p className="pd">{p.desc}</p><p className="pr">{p.price} <span>{p.per}</span></p><ul>{p.items.map(i => <li key={i}>{i}</li>)}</ul><a className={p.hot ? 'btn btn-gold' : 'btn btn-ghost'} style={p.hot ? undefined : { color: 'var(--navy)', borderColor: 'var(--navy)' }} href="#enquiry">Get Free Estimate</a></div>)}
      </div>
      <p className="price-note">Final estimates depend on location, built-up area, drawings, materials, specifications and site conditions. Share your requirements for a detailed free quotation.</p>
    </div></section>
    <Steps />
    <EnquirySection />
    <ContactSection />
  </main>;
}

export function ServicePage({ s }: { s: Service }) {
  return <main>
    <PageHero kicker={s.kicker} h1={s.h1} intro={s.intro} />
    <section className="sec"><div className="wrap"><div className="two-col">
      <div>
        <h2 style={{ marginTop: 0 }}>What&apos;s Included</h2>
        <ul className="check-list">{s.includes.map(i => <li key={i}>{i}</li>)}</ul>
        <p>{s.detail}</p>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginTop: 18 }}>
          <a className="btn btn-wa" href={WA_MSG(`Hi RNS Construction, I want details about ${s.name.toLowerCase()}.`)} target="_blank" rel="noopener">Enquire on WhatsApp</a>
          <a className="btn btn-gold" href="#enquiry">Get Free Quote</a>
        </div>
      </div>
      <div><img src={IMG.img8} alt={s.name} style={{ borderRadius: 16, width: '100%' }} /></div>
    </div></div></section>
    {s.slug === 'turnkey-projects' && <section className="sec alt" id="pricing"><div className="wrap">
      <div className="sec-head"><span className="kicker">Construction Packages</span><h2>Turnkey Packages and Rates</h2><p>Overall turnkey construction cost (material + labour).</p></div>
      <div className="price-grid">
        {PACKAGES.map(p => <div key={p.name} className={p.hot ? 'price-card hot' : 'price-card'}><h3>{p.name}</h3><p className="pd">{p.desc}</p><p className="pr">{p.price} <span>{p.per}</span></p><ul>{p.items.map(i => <li key={i}>{i}</li>)}</ul><a className={p.hot ? 'btn btn-gold' : 'btn btn-ghost'} style={p.hot ? undefined : { color: 'var(--navy)', borderColor: 'var(--navy)' }} href="#enquiry">Get Free Estimate</a></div>)}
      </div>
      <p className="price-note">Final estimates depend on location, built-up area, drawings, materials, specifications and site conditions. Share your requirements for a detailed free quotation.</p>
    </div></section>}
    <section className={s.slug === 'turnkey-projects' ? 'sec' : 'sec alt'}><div className="wrap">
      <div className="sec-head"><span className="kicker">Questions</span><h2>Common Questions</h2></div>
      {s.faq.map(f => <div key={f.q} className="faq-item"><h3>{f.q}</h3><p>{f.a}</p></div>)}
    </div></section>
    <Steps />
    <EnquirySection />
    <ContactSection />
  </main>;
}

export function AreaPage({ a }: { a: Area }) {
  return <main>
    <PageHero kicker={`Local Construction - ${a.name}`} h1={a.heading} intro={a.intro} />
    <section className="sec"><div className="wrap"><div className="two-col">
      <div>
        <h2 style={{ marginTop: 0 }}>{a.focus}</h2>
        <p>{a.detail}</p>
        <div className="link-cards" style={{ gridTemplateColumns: '1fr' }}>
          {a.s.map(x => <div key={x.t} className="link-card"><b>{x.t}</b><span>{x.d}</span></div>)}
        </div>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginTop: 18 }}>
          <a className="btn btn-wa" href={WA_MSG(`Hi RNS Construction, I have a project in ${a.name}. Please contact me.`)} target="_blank" rel="noopener">WhatsApp About {a.name}</a>
          <a className="btn btn-gold" href="#enquiry">Get Free Quote</a>
        </div>
      </div>
      <div>
        <h3 style={{ marginTop: 0 }}>Services in {a.name}</h3>
        <div className="link-cards" style={{ gridTemplateColumns: '1fr' }}>
          {SERVICES.map(s => <Link key={s.slug} className="link-card" to={`/services/${s.slug}`}><b>{s.name}</b><span className="go">View details &rarr;</span></Link>)}
        </div>
      </div>
    </div></div></section>
    <section className="sec alt"><div className="wrap">
      <div className="sec-head"><span className="kicker">Questions</span><h2>{a.name} - Common Questions</h2></div>
      {a.faq.map(f => <div key={f.q} className="faq-item"><h3>{f.q}</h3><p>{f.a}</p></div>)}
    </div></section>
    <EnquirySection />
    <ContactSection />
  </main>;
}

export function ProjectsPage() {
  return <main>
    <PageHero kicker="Projects" h1="Project Styles & Design Inspiration" intro="Construction and design styles we build - modern houses, villas, commercial buildings and interiors across Tricity. Real project photos are added as they are completed." />
    <section className="sec"><div className="wrap">
      <div className="proj-grid">
        {[
          { img: IMG.img4, t: 'Modern Independent House', d: 'Contemporary elevation with clean lines and premium finish.' },
          { img: IMG.img8, t: 'Luxury Villa Style', d: 'Large-format villa design with a modern facade.' },
          { img: IMG.img1, t: 'Exterior Elevation', d: 'Elevation design ideas for kothis and independent floors.' },
          { img: IMG.img3, t: 'Commercial Building', d: 'Showroom and office building styles.' },
          { img: IMG.img6, t: 'Residential Building', d: 'Multi-storey residential construction styles.' },
          { img: IMG.img7, t: 'Interior Design', d: 'Premium interior finishes - kitchen, ceiling and lighting.' },
        ].map(p => <div key={p.t} className="proj"><img src={p.img} alt={p.t} loading="lazy" /><div className="pj"><h3>{p.t}</h3><p>{p.d}</p></div></div>)}
      </div>
      <div className="note-strip">These are design styles for inspiration. Photos of completed RNS projects will be added here as they become available.</div>
    </div></section>
    <EnquirySection />
    <ContactSection />
  </main>;
}

const FAQS = [
  { q: 'What is the house construction cost in Mohali?', a: 'Civil construction (brick work and plaster, material + labour) is Rs. 1,100 per sq ft. Turnkey finishing packages: Standard Rs. 2,600-2,800 and Premium Rs. 3,000-4,500+ per sq ft. Final cost depends on plot size, design and materials. A detailed quotation is free.' },
  { q: 'Do you provide turnkey construction in Chandigarh and Panchkula?', a: 'Yes. RNS Construction provides complete turnkey construction in Mohali, Chandigarh, Panchkula, Zirakpur, Kharar, New Chandigarh and Pinjore - design, construction, interiors and key handover.' },
  { q: 'How long does house construction take?', a: 'The timeline depends on the plot size, design and scope of work. We provide a project-specific schedule after reviewing your requirements.' },
  { q: 'Is a free site visit available?', a: 'Yes. A free site visit is available in Mohali, Chandigarh, Panchkula, Zirakpur and nearby areas. Call or WhatsApp +91 87505 10489 to schedule.' },
  { q: 'Which areas do you serve?', a: 'We serve Mohali, Chandigarh, Panchkula, Zirakpur, Kharar, New Chandigarh and Pinjore. The office is at SCF 103, Phase 11, Mohali.' },
  { q: 'Do you handle only renovation or interiors, without full construction?', a: 'Yes. Renovation, floor additions, elevation change and interior finishing can be taken up as separate jobs for existing homes.' },
];

export function FaqPage() {
  return <main>
    <PageHero kicker="FAQ" h1="Frequently Asked Questions" intro="Common questions about house construction in Mohali, Chandigarh and Panchkula." />
    <section className="sec"><div className="wrap" style={{ maxWidth: 860 }}>
      {FAQS.map(f => <div key={f.q} className="faq-item"><h3>{f.q}</h3><p>{f.a}</p></div>)}
    </div></section>
    <EnquirySection />
    <ContactSection />
  </main>;
}

export function TermsPage() {
  return <main>
    <PageHero kicker="Terms" h1="Terms and Conditions" intro="The terms that apply to using this website and to enquiries made through it." />
    <section className="sec"><div className="wrap" style={{ maxWidth: 860 }}>
      <div className="faq-item"><h3>Website information</h3><p>This website introduces RNS Construction and its services. Discuss the details of your project with our team before relying on a price, package or timeline shown here.</p></div>
      <div className="faq-item"><h3>Quotations and project work</h3><p>Costs and schedules depend on the site, design, materials and scope of work. Confirm the scope, final price, payment schedule and project terms in a written quotation or agreement.</p></div>
      <div className="faq-item"><h3>Enquiries</h3><p>The enquiry form prepares a WhatsApp message. Review it in WhatsApp and send it yourself. A website enquiry alone does not confirm a booking or construction order.</p></div>
      <div className="faq-item"><h3>Project-specific policies</h3><p>Ask RNS Construction for the payment, cancellation, refund and warranty terms that apply to your project before making a commitment.</p></div>
    </div></section>
    <ContactSection />
  </main>;
}

export function AreasIndexNote() { return null; }

export function BlogPage() {
  return <main>
    <PageHero kicker="Blog" h1="Construction Updates - Mohali, Chandigarh & Punjab" intro="Rates, materials and project guidance from the Tricity construction market, written by RNS Construction." />
    <section className="sec"><div className="wrap" style={{ maxWidth: 860 }}>
      <div className="faq-item">
        <span className="kicker">Latest &middot; Building Rules &middot; Sep 2026</span>
        <h3>Punjab building rules amended - in force from 7 September 2026</h3>
        <p>The Punjab Urban Planning and Development Building (Second Amendment) Rules, 2026 were notified on 2 September and published in the Punjab Government Gazette (Extraordinary) on 7 September 2026, in force from that date. Key changes in the official notification (G.S.R.52): maximum floor-to-floor height for booths, shops and shop-cum-offices raised to 5.0 metres - this does not apply to shops or offices inside shopping malls, standalone commercial buildings, multiplexes or mixed-use projects; rooftop solar panel structures up to 2.4 metres clear height no longer count towards building height or FAR; a toilet up to 6 sq m is now permitted on the terrace; a new clearance zone applies for buildings near high-tension lines. These rules apply in areas governed by the Punjab Urban Planning and Development Building Rules, 2021, which cover the GMADA planning area. Note: these provisions are not a blanket permission for every property - always verify the applicable local authority rules and approvals for your specific plot or building before planning. Sources: <a href="https://archive.org/details/in.gazette.punjabdsa.2026-09-07.92432" target="_blank" rel="noopener">Punjab Government Gazette, 7 Sep 2026 (official record copy)</a> and <a href="https://www.hindustantimes.com/cities/chandigarh-news/punjab-eases-building-norms-for-shops-tightens-electrical-fire-safety-rules-101788980710331.html" target="_blank" rel="noopener">Hindustan Times, 10 Sep 2026</a>. Verified 13 Oct 2026.</p>
      </div>
      <div className="faq-item">
        <span className="kicker">Latest &middot; Approvals &middot; Oct 2026</span>
        <h3>Eco City 3, New Chandigarh gets environmental clearance</h3>
        <p>GMADA's planned Eco City 3 township in New Chandigarh (Mullanpur) has received environmental clearance from Punjab's State Environment Impact Assessment Authority. The township covers 716 acres across nine villages, with residential plots to be allotted by draw of lots and commercial sites by open auction. Important: clearance is an approval milestone, not a launch - no public plot booking, draw dates or prices were found on the GMADA pages checked on 13 October 2026 (<a href="https://www.gmada.gov.in/en/node/12161" target="_blank" rel="noopener">GMADA's Eco City 3 notification page</a> and <a href="https://www.gmada.gov.in/en" target="_blank" rel="noopener">gmada.gov.in</a>). Source: <a href="https://timesofindia.indiatimes.com/city/chandigarh/eco-city-3-clears-key-hurdle-716-acre-new-chandigarh-township-set-to-take-shape/articleshow/134876674.cms" target="_blank" rel="noopener">Times of India, 12 Oct 2026</a>. Verified 13 Oct 2026.</p>
      </div>
      <div className="faq-item">
        <span className="kicker">Latest &middot; Market &middot; Oct 2026</span>
        <h3>GMADA auctions and some project launches paused</h3>
        <p>Hindustan Times reported on 9 October 2026 that after Enforcement Directorate searches at GMADA in September, the housing department put some activities on hold: the state-wide auction of residential and commercial properties planned for 24 September was postponed, the Eco City-2 (Extension) launch is on hold, and the National Housing and Urban Innovation Summit is deferred to November. Separately, GMADA's <a href="https://gmada.gov.in/en/auction-notices" target="_blank" rel="noopener">auction notices page</a>, checked on 13 October 2026, lists no revised date for the postponed auction. If you are waiting for a GMADA auction, plan for revised timelines. Source: <a href="https://www.hindustantimes.com/cities/chandigarh-news/after-ed-searches-gmada-treads-cautiously-puts-projects-auctions-on-hold-101791484644993.html" target="_blank" rel="noopener">Hindustan Times, 9 Oct 2026</a>. Verified 13 Oct 2026.</p>
      </div>
      <div className="faq-item">
        <span className="kicker">Latest &middot; Development &middot; Oct 2026</span>
        <h3>GMADA plans Rs. 15,000 crore raise for 14 projects</h3>
        <p>In an affidavit before the Punjab and Haryana High Court, GMADA said it has taken up 14 development projects needing about Rs. 17,686 crore for land acquisition and development, and proposes to raise Rs. 15,000 crore through borrowing under Section 51 of the Punjab Regional and Town Planning Act, 1955. This is a proposal under scrutiny, not sanctioned spending yet. Source: <a href="https://www.tribuneindia.com/news/punjab/gmada-justifies-15k-cr-fundraising-for-land-acquisition/" target="_blank" rel="noopener">The Tribune, 9 Oct 2026</a>. Verified 13 Oct 2026.</p>
      </div>
      <div className="faq-item">
        <span className="kicker">Rates &middot; Mohali</span>
        <h3>House construction cost in Mohali - current package rates</h3>
        <p>Civil construction (brick work and plaster, material + labour) currently runs at Rs. 1,100 per sq ft. Turnkey finishing packages: Standard finishing Rs. 2,600-2,800 per sq ft with good-quality tiles, semi modular kitchen and branded fittings; Premium / Luxury finishing Rs. 3,000-4,500+ per sq ft with high-end materials, custom design and luxury finishes. Final cost for any plot depends on size, design, materials and site conditions - a detailed quotation is free on request.</p>
      </div>
      <div className="faq-item">
        <span className="kicker">Guide &middot; Tricity</span>
        <h3>Civil vs turnkey construction - which should you choose?</h3>
        <p>Civil construction covers brick work and plaster - material and labour included. It suits owners who want to manage finishing separately or complete the home in stages. Turnkey construction covers design, construction and interiors through to key handover - one team and one clear quotation. Share your plot details and we will help you pick the right scope for your budget.</p>
      </div>
      <div className="faq-item">
        <span className="kicker">Guide &middot; Planning</span>
        <h3>What decides your final construction cost?</h3>
        <p>Plot size and built-up area, the design and drawings, the materials and brands you choose, the finishing level (civil, standard or premium), and site conditions. This is why RNS prepares a clear, item-wise quotation for each project instead of one flat rate multiplied by area. Share your plot details for a free detailed estimate.</p>
      </div>
      <div className="faq-item">
        <span className="kicker">Guide &middot; Floor Additions</span>
        <h3>Planning to add a floor? Check the structure first</h3>
        <p>A first-floor or second-floor addition starts with the existing building, not the new one. The foundation and columns must be assessed for the extra load before scope or cost is agreed. Send existing plans and photos to begin the discussion, and expect an on-site structural review before a final quotation. Planned right, an addition also lets you refresh the elevation at the same time.</p>
      </div>
      <div className="faq-item">
        <span className="kicker">Guide &middot; Hiring</span>
        <h3>5 questions to ask before finalizing a contractor</h3>
        <p>1) Will the quotation be item-wise and in writing? 2) Which material brands are included? 3) How will progress be shared - photos, videos, site visits? 4) What is the payment schedule tied to? 5) Who supervises the site daily? Clear answers to these five questions separate dependable teams from the rest.</p>
      </div>
      <div className="note-strip">More updates on Mohali, Chandigarh and Punjab construction - price changes, material trends and approval news - will be published here. Follow us on Instagram or WhatsApp us to get updates directly.</div>
    </div></section>
    <EnquirySection />
    <ContactSection />
  </main>;
}
