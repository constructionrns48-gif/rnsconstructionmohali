import React from 'react';
import { Route, Routes } from '@instinct/files';
import './site.css';
import { AREAS, SERVICES } from './data';
import { ChatWidget, SiteFooter, SiteHeader, WaFloat } from './components';
import { Home } from './Home';
import { AboutPage, AreaPage, BlogPage, FaqPage, ProjectsPage, ServicePage, ServicesPage, TermsPage } from './pages';

export function App() {
  return <>
    <SiteHeader />
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<AboutPage />} />
      <Route path="/services" element={<ServicesPage />} />
      {SERVICES.map(s => <Route key={s.slug} path={`/services/${s.slug}`} element={<ServicePage s={s} />} />)}
      <Route path="/projects" element={<ProjectsPage />} />
      {AREAS.map(a => <Route key={a.slug} path={`/areas/${a.slug}`} element={<AreaPage a={a} />} />)}
      <Route path="/faq" element={<FaqPage />} />
      <Route path="/blog" element={<BlogPage />} />
      <Route path="/terms" element={<TermsPage />} />
    </Routes>
    <SiteFooter />
    <ChatWidget />
    <WaFloat />
  </>;
}
