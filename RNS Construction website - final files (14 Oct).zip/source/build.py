import re, html as H, json, os

RAW = '/tmp/rns-icons-dist/raw'
DIST = '/tmp/rns-icons-dist/dist'
os.makedirs(DIST, exist_ok=True)

kw_raw = open('/tmp/keywords.txt').read().strip()
kw_all = kw_raw[len('content="'):-1]

DESC_DEF = 'House construction, turnkey projects, renovation and interiors in Mohali, Chandigarh, Panchkula and nearby areas. Contact RNS Construction for a quotation.'

PAGES = {
 'index': dict(title='RNS Construction | House Construction in Mohali & Tricity', canon='', desc='RNS Construction Mohali offers residential and commercial construction, turnkey projects, architectural planning, interior design and home renovation in Mohali, Chandigarh, Zirakpur, Panchkula and nearby areas. Contact us for a consultation.', kw=kw_all, gsc=True),
 'about': dict(title='About Us - RNS Construction Mohali', canon='about.html', desc=DESC_DEF),
 'services': dict(title='Our Services - RNS Construction Mohali', canon='services.html', desc=DESC_DEF, kw='house construction in Mohali, commercial construction Chandigarh, turnkey construction Punjab, interior design, home renovation, civil contractor in Mohali'),
 'projects': dict(title='Our Projects - RNS Construction Mohali', canon='projects.html', desc=DESC_DEF),
 'faq': dict(title='FAQ - RNS Construction Mohali', canon='faq.html', desc=DESC_DEF, kw='construction cost per sq ft Mohali, home construction cost in Mohali, turnkey construction, free site visit'),
 'terms': dict(title='Terms and Conditions - RNS Construction Mohali', canon='terms.html', desc=DESC_DEF),
 'blog': dict(title='Construction Updates Blog - RNS Construction Mohali', canon='blog.html', desc='Latest Mohali, Chandigarh and Punjab construction updates - building rules, approvals, rates and project guidance from RNS Construction.', kw='construction cost per sq ft Mohali, Mohali, Punjab building rules, GMADA, home construction cost in Punjab'),
 'services-house-construction': dict(title='House Construction in Mohali - RNS Construction', canon='services-house-construction.html', desc='House construction in Mohali with clear item-wise quotations - civil, standard and premium packages. Free site visit across Tricity.', kw='house construction in Mohali, house builder in Mohali, kothi construction, villa construction, residential construction Punjab'),
 'services-commercial-building': dict(title='Commercial Building Construction in Mohali - RNS Construction', canon='services-commercial-building.html', desc='Commercial building construction in Mohali and Tricity - showrooms, shops and office buildings built by RNS Construction.', kw='commercial construction Chandigarh, commercial building construction, showroom construction, shop construction, office construction'),
 'services-turnkey-projects': dict(title='Turnkey Construction Packages in Mohali - RNS Construction', canon='services-turnkey-projects.html', desc='Turnkey construction packages in Mohali: civil Rs.1,100/sq ft, standard Rs.2,600-2,800/sq ft, premium Rs.3,000-4,500+/sq ft. Material and labour included.', kw='turnkey construction Punjab, turnkey construction, construction cost per sq ft Mohali, home construction cost in Mohali'),
 'services-architectural-design': dict(title='Architectural & Structural Design in Mohali - RNS Construction', canon='services-architectural-design.html', desc='Architectural and structural design services in Mohali - house plans, elevations and structural drawings by RNS Construction.', kw='interior contractor Chandigarh, residential construction Punjab, builders in Mohali'),
 'services-interior-design': dict(title='Interior Design in Mohali - RNS Construction', canon='services-interior-design.html', desc='Interior design in Mohali - modular kitchens, false ceiling, flooring, painting and finishing by RNS Construction.', kw='interior design, interior contractor Chandigarh, false ceiling, flooring, painting and finishing'),
 'services-renovation': dict(title='Home Renovation & Remodeling in Mohali - RNS Construction', canon='services-renovation.html', desc='Home renovation and remodeling in Mohali - floor additions, elevation changes and complete makeovers by RNS Construction.', kw='home renovation Mohali, home renovation, house remodelling, repair and extension work, home renovation Chandigarh'),
 'areas-mohali': dict(title='Construction Company in Mohali - RNS Construction', canon='areas-mohali.html', desc='RNS Construction in Mohali - house construction, floor additions and renovation across Phase 11, Sunny Enclave and all Mohali sectors.', kw='construction company in Mohali, house construction in Mohali, builders in Mohali, civil contractor in Mohali, Mohali'),
 'areas-zirakpur': dict(title='Construction Company in Zirakpur - RNS Construction', canon='areas-zirakpur.html', desc='RNS Construction in Zirakpur - turnkey house construction and finishing packages with free site visit.', kw='builders in Zirakpur, Zirakpur, turnkey construction, construction company Tricity'),
 'areas-kharar': dict(title='Construction Company in Kharar - RNS Construction', canon='areas-kharar.html', desc='RNS Construction in Kharar - plot construction, boundary walls and house building with clear quotations.', kw='builders in Kharar, Kharar, boundary wall construction, boundary wall construction Mohali, house builder in Mohali'),
 'areas-chandigarh': dict(title='Construction Company in Chandigarh - RNS Construction', canon='areas-chandigarh.html', desc='RNS Construction in Chandigarh - renovation, interiors and house construction across Chandigarh sectors.', kw='construction company in Chandigarh, house construction in Chandigarh, builders in Chandigarh, home renovation Chandigarh, interior contractor Chandigarh'),
 'areas-panchkula': dict(title='Construction Company in Panchkula - RNS Construction', canon='areas-panchkula.html', desc='RNS Construction in Panchkula - house construction, extensions and finishing work across Panchkula.', kw='builders in Panchkula, Panchkula, construction company Tricity, residential construction Punjab'),
}

BUSINESS_LD = {"@context":"https://schema.org","@type":"HomeAndConstructionBusiness","name":"RNS Construction","alternateName":"RNS Construction Mohali","image":"https://rnsconstructionmohali.com/apple-touch-icon.png","@id":"https://rnsconstructionmohali.com/","url":"https://rnsconstructionmohali.com/","telephone":"+918750510489","email":"rnsconstructionmohali99@gmail.com","priceRange":"₹₹","address":{"@type":"PostalAddress","streetAddress":"SCF 103, 1st Floor, Phase 11, Above Gadget World","addressLocality":"Mohali","addressRegion":"Punjab","postalCode":"160062","addressCountry":"IN"},"geo":{"@type":"GeoCoordinates","latitude":30.7046,"longitude":76.7179},"openingHoursSpecification":[{"@type":"OpeningHoursSpecification","dayOfWeek":["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"opens":"09:00","closes":"19:00"}],"areaServed":[{"@type":"City","name":c} for c in ["Mohali","Chandigarh","Panchkula","Zirakpur","Kharar","New Chandigarh","Pinjore"]],"sameAs":["https://www.instagram.com/rnsconstruction99","https://www.facebook.com/profile.php?id=61592053485489","https://youtube.com/@rnsconstructionmohali"],"description":"Best Construction Company in Mohali, Chandigarh, Panchkula & Punjab. Expert in House Construction, Turnkey Projects, Renovation and Interiors."}

SERVICE_LD = {
 'services-house-construction': ('House Construction', 'Complete house construction in Mohali and Tricity - civil structure, finishing and turnkey packages with item-wise quotations.'),
 'services-commercial-building': ('Commercial Building Construction', 'Commercial building construction in Mohali - showrooms, shops and office buildings.'),
 'services-turnkey-projects': ('Turnkey Construction', 'End-to-end turnkey construction - design, construction, interiors and key handover for residential projects in Tricity.'),
 'services-architectural-design': ('Architectural and Structural Design', 'House plans, 3D elevations and structural drawings in Mohali and Tricity.'),
 'services-interior-design': ('Interior Design', 'Interior design in Mohali - kitchens, false ceiling, flooring, painting and finishing.'),
 'services-renovation': ('House Renovation', 'Old house renovation, floor addition, elevation change and complete modern makeovers in Mohali and surrounding areas.'),
}

REWRITES = [
 ('/services/house-construction', '/services-house-construction.html'),
 ('/services/commercial-building', '/services-commercial-building.html'),
 ('/services/turnkey-projects', '/services-turnkey-projects.html'),
 ('/services/architectural-design', '/services-architectural-design.html'),
 ('/services/interior-design', '/services-interior-design.html'),
 ('/services/renovation', '/services-renovation.html'),
 ('/areas/mohali', '/areas-mohali.html'),
 ('/areas/zirakpur', '/areas-zirakpur.html'),
 ('/areas/kharar', '/areas-kharar.html'),
 ('/areas/chandigarh', '/areas-chandigarh.html'),
 ('/areas/panchkula', '/areas-panchkula.html'),
 ('/about', '/about.html'),
 ('/services', '/services.html'),
 ('/projects', '/projects.html'),
 ('/faq', '/faq.html'),
 ('/terms', '/terms.html'),
 ('/blog', '/blog.html'),
]

def esc(s): return H.escape(s, quote=True)

for name, cfg in PAGES.items():
    h = open(f'{RAW}/{name}.html', encoding='utf-8').read()
    # remove kit stylesheet link
    h = h.replace('<link rel="stylesheet" href="file:///skills/platform/files/render/styles.css">', '')
    # remove render width style
    h = re.sub(r'<style>html, body \{ margin: 0; \} html \{ background: transparent; \} body \{ width: \d+px; \}</style>', '<style>html, body { margin: 0; }</style>', h)
    # rewrite internal links (exact attribute match)
    for src, dst in REWRITES:
        h = h.replace(f'href="{src}"', f'href="{dst}"')
    # SEO head
    canon = 'https://rnsconstructionmohali.com/' + cfg['canon']
    head = []
    head.append(f'<title>{esc(cfg["title"])}</title>')
    head.append(f'<meta name="description" content="{esc(cfg["desc"])}"/>')
    if cfg.get('kw'): head.append(f'<meta name="keywords" content="{esc(cfg["kw"])}"/>')
    head.append('<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1"/>')
    if cfg.get('gsc'): head.append('<meta name="google-site-verification" content="google72261b44e3321d56"/>')
    head.append(f'<link rel="canonical" href="{canon}"/>')
    head.append('<link rel="icon" href="/favicon.png" sizes="96x96" type="image/png"/>')
    head.append('<link rel="apple-touch-icon" href="/apple-touch-icon.png" sizes="180x180"/>')
    head.append(f'<meta property="og:title" content="{esc(cfg["title"])}"/>')
    head.append(f'<meta property="og:description" content="{esc(cfg["desc"])}"/>')
    head.append(f'<meta property="og:url" content="{canon}"/>')
    head.append('<meta property="og:type" content="website"/>')
    lds = [dict(BUSINESS_LD, url=canon)]
    if name == 'faq':
        items = re.findall(r'<div class="faq-item">.*?<h3>(.*?)</h3>.*?<p>(.*?)</p>', open(f'{RAW}/faq.html', encoding='utf-8').read(), re.S)
        ents = [{"@type":"Question","name":re.sub(r'<[^>]+>','',q).strip(),"acceptedAnswer":{"@type":"Answer","text":re.sub(r'<[^>]+>','',a).strip()}} for q,a in items]
        lds.append({"@context":"https://schema.org","@type":"FAQPage","mainEntity":ents})
    if name in SERVICE_LD:
        st, sd = SERVICE_LD[name]
        lds.append({"@context":"https://schema.org","@type":"Service","serviceType":st,"provider":{"@type":"HomeAndConstructionBusiness","name":"RNS Construction","telephone":"+918750510489"},"areaServed":["Mohali","Chandigarh","Panchkula","Zirakpur","Kharar","New Chandigarh"],"description":sd})
    for ld in lds:
        head.append('<script type="application/ld+json">' + json.dumps(ld, ensure_ascii=False) + '</script>')
    h = h.replace('</head>', ''.join(head) + '</head>')
    h = h.replace('</body>', '<script src="/site.js"></script></body>')
    open(f'{DIST}/{name}.html', 'w', encoding='utf-8').write(h)
    print(name, len(h))
