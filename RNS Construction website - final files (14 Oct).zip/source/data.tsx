import img1 from './photos/img1.jpg';
import img2 from './photos/img2.jpg';
import img3 from './photos/img3.jpg';
import img4 from './photos/img4.jpg';
import img5 from './photos/img5.jpg';
import img6 from './photos/img6.jpg';
import img7 from './photos/img7.jpg';
import img8 from './photos/img8.jpg';
import logo from './photos/logo.png';

export const IMG = { img1, img2, img3, img4, img5, img6, img7, img8, logo };

export const PHONE = '+918750510489';
export const PHONE_DISPLAY = '+91 87505 10489';
export const WA = 'https://wa.me/918750510489';
export const WA_MSG = (t: string) => `${WA}?text=${encodeURIComponent(t)}`;
export const ADDRESS = 'SCF 103, 1st Floor, Phase 11, Above Gadget World, Mohali, Punjab 160062';
export const EMAIL = 'rnsconstructionmohali99@gmail.com';
export const MAPS_DIR = 'https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent('SCF 103, 1st Floor, Phase 11, Above Gadget World, Mohali, Punjab 160062');
export const REVIEWS_URL = 'https://share.google/OkGZxYW0gj5gXvu1u';
export const INSTAGRAM = 'https://www.instagram.com/rnsconstruction99';
export const FACEBOOK = 'https://www.facebook.com/profile.php?id=61592053485489';
export const YOUTUBE = 'https://youtube.com/@rnsconstructionmohali';
export const STATS = [
  { n: '10+', l: 'Years of Experience' },
  { n: '25,000+', l: 'Sq. Ft. Built-up Area' },
  { n: '30+', l: 'Completed Projects' },
];

export interface Service {
  slug: string; name: string; h1: string; kicker: string; intro: string;
  includes: string[]; detail: string; faq: { q: string; a: string }[];
}

export const SERVICES: Service[] = [
  {
    slug: 'house-construction', name: 'House Construction',
    h1: 'House Construction in Mohali, Chandigarh & Nearby Areas',
    kicker: 'Residential Construction',
    intro: 'Complete residential construction from foundation to finishing - houses, kothis, villas and independent floors built with quality branded materials and clear, item-wise estimates.',
    includes: [
      'Foundation, RCC columns and structure work',
      'Brick work / AAC block walls and plaster',
      'Electrical, plumbing and sanitary work',
      'Flooring, tiles and finishing',
      'Elevation design and exterior finishing',
      'Free site visit and detailed quotation',
    ],
    detail: 'Share your plot location, size and the kind of home you want. If you already have drawings, send them over. We discuss design, materials and scope before work starts, and you get regular photo and video updates during construction.',
    faq: [
      { q: 'What is the house construction cost per sq ft in Mohali?', a: 'Civil construction (brick work and plaster, material + labour) is Rs. 1,100 per sq ft. Turnkey finishing packages: Standard Rs. 2,600-2,800 and Premium Rs. 3,000-4,500+ per sq ft. Final cost depends on plot size, design and materials - a detailed quotation is free.' },
      { q: 'Can I construct only one floor now and add floors later?', a: 'Yes. We plan the structure so floors can be added later, and we also handle first-floor and second-floor additions on existing houses after a structural check.' },
    ],
  },
  {
    slug: 'commercial-building', name: 'Commercial Building Construction',
    h1: 'Commercial Building Construction in Mohali & Tricity',
    kicker: 'Commercial Construction',
    intro: 'Construction and finishing for commercial buildings, showrooms, shops and offices - handled under one roof, from structure to interiors.',
    includes: [
      'Commercial buildings, showrooms and shops',
      'Office construction and fit-outs',
      'Structure, brickwork and plaster',
      'Electrical, plumbing and HVAC coordination',
      'Interior finishing for customer-facing spaces',
      'Item-wise estimate before work starts',
    ],
    detail: 'Tell us about your site and the kind of commercial space you want to build. We plan the structure and finishing around your business use, with a clear timeline.',
    faq: [
      { q: 'Do you build showrooms and shops?', a: 'Yes. We construct and finish showrooms, shops and office spaces across Mohali, Chandigarh, Zirakpur, Kharar and Panchkula.' },
      { q: 'Can you handle both structure and interiors for a commercial space?', a: 'Yes. Commercial projects can be taken up end to end - structure, services and interior finishing together.' },
    ],
  },
  {
    slug: 'turnkey-projects', name: 'Turnkey Projects',
    h1: 'Turnkey Construction Projects - Design to Key Handover',
    kicker: 'Turnkey Construction',
    intro: 'Design + Construction + Interiors in one contract. You just take the keys of your dream home. Transparent packages.',
    includes: [
      'Architectural design and structural planning',
      'Complete civil construction',
      'Electrical, plumbing and sanitary work',
      'Full interiors: kitchen, wardrobes, false ceiling, lighting',
      'Regular photo and video progress updates',
      'Quality check and key handover',
    ],
    detail: 'In a turnkey project, RNS brings design, construction and interiors together through to key handover. Packages below are overall turnkey cost (material + labour); the final estimate depends on location, built-up area, drawings, materials and site conditions.',
    faq: [
      { q: 'What does a turnkey package include?', a: 'Everything from design to handover: structure, finishing, electrical, plumbing and interiors as per the package you choose. You get one clear item-wise quotation.' },
      { q: 'How do I get an exact price for my plot?', a: 'Share your plot size, location and requirements on WhatsApp or through the enquiry form. We arrange a free site visit and prepare a project-specific quotation.' },
    ],
  },
  {
    slug: 'architectural-design', name: 'Architectural & Structural Design',
    h1: 'Architectural & Structural Design Services',
    kicker: 'Design & Planning',
    intro: 'Architectural planning, structural design and elevation design for houses and commercial buildings - the right drawings before the right construction.',
    includes: [
      'House plans and floor layouts',
      'Structural design and drawings',
      '3D elevation design',
      'Vastu-friendly planning on request',
      'Drawings for approval and construction',
      'Design support through the build',
    ],
    detail: 'Good construction starts on paper. We prepare design options with clear drawings, so you know exactly what will be built before work starts.',
    faq: [
      { q: 'Can I get only drawings without construction?', a: 'Yes. Architectural and structural design can be taken as a separate service, with drawings you can use for approval and construction.' },
      { q: 'Do you design elevations for existing houses?', a: 'Yes. Elevation design for a new or existing house can be planned along with construction or as a separate job.' },
    ],
  },
  {
    slug: 'interior-design', name: 'Interior Design',
    h1: 'Interior Design & Finishing Services',
    kicker: 'Interiors',
    intro: 'Modular kitchen, wardrobes, false ceiling, lighting, flooring and painting - complete interior design packages for new and existing homes.',
    includes: [
      'Modular kitchen and wardrobes',
      'False ceiling and lighting design',
      'Flooring, tiles and painting',
      'Full home interior packages',
      'Office and showroom interiors',
      'Material and finish selection support',
    ],
    detail: 'Interior work can be part of a construction project or a standalone job for your existing home or commercial space. Share photos and sizes to start the discussion.',
    faq: [
      { q: 'Can you do interiors for an already-built house?', a: 'Yes. Kitchen changes, flooring, painting, false ceiling and full interior finishing can be taken up separately for existing homes.' },
      { q: 'Do you provide interior packages with construction?', a: 'Yes. Standard and Premium finishing packages include interior work, and Premium includes a full interiors package.' },
    ],
  },
  {
    slug: 'renovation', name: 'Home Renovation & Remodeling',
    h1: 'Home Renovation, Floor Addition & Remodeling',
    kicker: 'Renovation & Remodeling',
    intro: 'Old house renovation, floor additions, elevation change and complete modern makeovers - with structural checks before any addition.',
    includes: [
      'Complete old house renovation',
      'First-floor and second-floor additions',
      'House extensions',
      'Elevation change and exterior makeover',
      'Repairs, flooring and repainting',
      'Structural assessment before additions',
    ],
    detail: 'For a renovation, tell us what stays and what changes. For a floor addition, the existing structure is checked first, then the addition is planned and quoted.',
    faq: [
      { q: 'Can a floor addition be quoted without seeing the house?', a: 'Send existing plans and photos to begin, but an on-site review and structural assessment comes before final scope or cost.' },
      { q: 'Do you renovate old houses completely?', a: 'Yes. Complete makeovers covering structure repairs, interiors and elevation are a regular part of our work.' },
    ],
  },
];

export interface Area {
  slug: string; name: string; heading: string; intro: string; focus: string; detail: string;
  s: { t: string; d: string }[]; faq: { q: string; a: string }[];
}

export const AREAS: Area[] = [
  {
    slug: 'mohali', name: 'Mohali',
    heading: 'House Construction and Renovation in Mohali',
    intro: 'Planning a new home or improving an existing one in Mohali? RNS Construction is based in Phase 11, Mohali, and offers house construction, turnkey work, renovations and interiors.',
    focus: 'Start with the site and the scope',
    detail: 'For a plot in Mohali, share its location, size and the kind of home you want. If you already have drawings, send them over. For a renovation, tell us what stays and what changes. We can discuss a site visit before giving a quotation.',
    s: [
      { t: 'House construction', d: 'New homes from foundation to finishing, with design and material choices discussed before work starts.' },
      { t: 'Floor additions', d: 'For a first-floor or second-floor addition, structural checks and the existing building come first.' },
      { t: 'Renovation and interiors', d: 'Kitchen changes, flooring, painting, elevation work and interior finishing can be discussed separately.' },
    ],
    faq: [
      { q: 'Can I ask about only an extension in Mohali?', a: 'Yes. RNS lists floor additions and house extensions as separate services. Share the existing house details and the space you want to add.' },
      { q: 'Where is the RNS office?', a: 'SCF 103, 1st Floor, Phase 11, Above Gadget World, Mohali, Punjab 160062.' },
    ],
  },
  {
    slug: 'zirakpur', name: 'Zirakpur',
    heading: 'House Construction and Turnkey Work in Zirakpur',
    intro: 'Building a home in Zirakpur? RNS Construction serves Zirakpur from its Mohali office, with house construction, turnkey projects, floor additions and elevation design.',
    focus: 'Discuss the plot before a quote',
    detail: 'Send the plot location, approximate size and any drawings. If you need an end-to-end handover, ask about turnkey scope; if you only need the structure or finishing, say so up front. A site visit helps narrow the work and quotation.',
    s: [
      { t: 'Turnkey home construction', d: 'Discuss design, structure and interiors as one project, or specify the parts you already have in place.' },
      { t: 'Floor addition and extension', d: 'For an existing house, discuss the current structure and the proposed additional floor before planning work.' },
      { t: 'Elevation design', d: 'Plan the visible front of a new or existing house along with construction or as a separate job.' },
    ],
    faq: [
      { q: 'Does RNS serve Zirakpur from Mohali?', a: 'Yes. Zirakpur is among the areas RNS serves; the office is in Phase 11, Mohali, a short drive away.' },
      { q: 'Can I ask for a turnkey quote in Zirakpur?', a: 'Yes. Share the plot size and requirements, and ask specifically for a turnkey scope so design, construction and interiors are quoted together.' },
    ],
  },
  {
    slug: 'kharar', name: 'Kharar',
    heading: 'House Construction and Plot Work in Kharar',
    intro: 'Have a plot in Kharar? RNS Construction handles new house construction, plot development work, boundary walls and gates in Kharar and nearby areas.',
    focus: 'From empty plot to finished home',
    detail: 'Many Kharar projects start with an empty plot. Share the plot location and size, and mention if you also need a boundary wall or gate. We can discuss the sequence - boundary first, then design and construction.',
    s: [
      { t: 'New house construction', d: 'Complete house construction from foundation to finishing on your Kharar plot.' },
      { t: 'Plot development', d: 'Basic site preparation and planning before construction starts.' },
      { t: 'Boundary wall and gate', d: 'Boundary wall and gate construction, as a first step or a separate job.' },
    ],
    faq: [
      { q: 'Can RNS build only a boundary wall in Kharar?', a: 'Yes. Boundary walls and gates can be taken up as a separate job before or alongside house construction.' },
      { q: 'Is a site visit available in Kharar?', a: 'Yes. Free site visits are available in Kharar. Call or WhatsApp to schedule.' },
    ],
  },
  {
    slug: 'chandigarh', name: 'Chandigarh',
    heading: 'Renovation, Interiors and House Construction in Chandigarh',
    intro: 'Own a house in Chandigarh that needs work? RNS Construction provides home renovation, interior finishing and new construction across Chandigarh.',
    focus: 'Renovation-friendly planning',
    detail: 'Chandigarh work often involves older houses: renovations, interior upgrades and structural changes. Tell us the sector, the age of the house and what you want changed. We plan the work so daily life is disturbed as little as possible.',
    s: [
      { t: 'Home renovation', d: 'Complete renovation of older houses, planned in stages if you are living in the house.' },
      { t: 'Interior finishing', d: 'Kitchens, wardrobes, false ceiling, lighting, flooring and painting.' },
      { t: 'New construction', d: 'House construction on residential plots, with drawings and approvals support.' },
    ],
    faq: [
      { q: 'Do you take renovation work in Chandigarh sectors?', a: 'Yes. Renovation and interior work across Chandigarh sectors is a regular part of our work.' },
      { q: 'Can interiors be done without full renovation?', a: 'Yes. Interior finishing can be a standalone job - share photos and room sizes to start.' },
    ],
  },
  {
    slug: 'panchkula', name: 'Panchkula',
    heading: 'House Extensions and Construction in Panchkula',
    intro: 'Need more space in Panchkula? RNS Construction handles floor additions, house extensions, renovation and new construction in Panchkula.',
    focus: 'Add space to the house you have',
    detail: 'For an extension or floor addition in Panchkula, share the existing house details, photos and any drawings. A structural review comes first, then scope and quotation.',
    s: [
      { t: 'Floor addition', d: 'Additional floors on existing houses, after structural checks.' },
      { t: 'House construction', d: 'New house construction from foundation to finishing.' },
      { t: 'Renovation and interiors', d: 'Renovation, remodeling and interior finishing for existing homes.' },
    ],
    faq: [
      { q: 'Can RNS visit a site in Panchkula?', a: 'Yes. Free site visits are available in Panchkula. Contact RNS to arrange a suitable time.' },
      { q: 'Can a floor addition be quoted without seeing the house?', a: 'Send existing plans and photos to begin, but ask for an on-site review and structural assessment before agreeing on scope or cost.' },
    ],
  },
];

export const PACKAGES = [
  { name: 'Civil Construction', desc: 'Brick work and plaster, material + labour.', price: 'Rs. 1,100', per: 'per sq. ft.', items: ['Brick work and plaster', 'Material and labour included'] },
  { name: 'Standard Finishing', desc: 'Good-quality standard finishing, material + labour.', price: 'Rs. 2,600 - 2,800', per: 'per sq. ft.', items: ['Good-quality tiles and flooring', 'Semi modular kitchen', 'Branded sanitary & electrical fittings'], hot: true },
  { name: 'Premium / Luxury Finishing', desc: 'High-end luxury construction, material + labour.', price: 'Rs. 3,000 - 4,500+', per: 'per sq. ft.', items: ['Imported / high-end materials', 'Custom design', 'Luxury finishes'] },
];

export const STEPS = [
  { t: 'Consultation', d: 'Call or WhatsApp us. Share your plot details, budget and requirements.' },
  { t: 'Design & Quotation', d: 'We prepare design options and a clear item-wise quotation.' },
  { t: 'Construction', d: 'Work starts with regular photo and video updates. You can visit the site anytime.' },
  { t: 'Key Handover', d: 'Quality check, final finishing and the keys of your dream home handed over.' },
];

export const PROJECT_STYLES = [
  { img: 'img4', t: 'Modern Independent House', d: 'Contemporary elevation with clean lines and premium finish.' },
  { img: 'img8', t: 'Luxury Villa Style', d: 'Large-format villa design with modern facade.' },
  { img: 'img1', t: 'Exterior Elevation', d: 'Elevation design ideas for kothis and independent floors.' },
  { img: 'img3', t: 'Commercial Building', d: 'Showroom and office building styles.' },
  { img: 'img6', t: 'Residential Building', d: 'Multi-storey residential construction styles.' },
  { img: 'img7', t: 'Interior Design', d: 'Premium interior finishes - kitchen, ceiling and lighting.' },
];
